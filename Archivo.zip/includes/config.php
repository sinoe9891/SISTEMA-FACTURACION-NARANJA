<?php
// config.php

define('DB_HOST', 'localhost');
define('DB_NAME', 'facturacion_saas');
define('DB_USER', 'root');
define('DB_PASS', ''); // Cambia esto por tu contraseña si aplica

// Ruta base del sistema
define('BASE_URL', 'http://localhost/facturacion-saas/'); // Ajusta al dominio real
?>
